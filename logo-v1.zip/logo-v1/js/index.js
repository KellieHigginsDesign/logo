TweenMax.to('#Rectangle_Top', 4.0, {
  x: 281,
  ease: Power1.easeInOut,
  delay: 1 });


TweenMax.to('#Rectangle_Bottom', 4.0, {
  x: 281,
  ease: Power1.easeInOut,
  delay: 1 });


TweenMax.to('#Center_Triangle', 4.0, {
  x: 150,
  ease: Power1.easeInOut,
  delay: 1 });